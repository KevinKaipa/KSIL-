const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DB_PATH = path.join(__dirname, 'data', 'db.json');
const PORT = process.env.PORT || 4000;

// Grading policy: students need at least this attendance % to be
// eligible at all; the rest of the grade comes entirely from the
// final exam average. Change PASS_MARK if the institute's passing
// threshold for the exam average differs from 50%.
const ATTENDANCE_THRESHOLD = 70;
const PASS_MARK = 50;

// Change this (or set the ADMIN_PASSWORD environment variable) to
// control who can log in as Admin. This is intentionally simple —
// fine for a small trusted office network, not meant for public
// internet use.
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'kingsejong2026';

// In-memory session tokens. Cleared whenever the server restarts,
// which just means everyone has to log in again — no big deal for
// a small local tool.
const adminSessions = new Set();
const studentSessions = new Map(); // token -> studentId

function newToken() {
  return crypto.randomBytes(24).toString('hex');
}

function requireAdmin(req, res, next) {
  const token = (req.headers.authorization || '').replace('Bearer ', '');
  if (!token || !adminSessions.has(token)) {
    return res.status(401).json({ error: 'Admin login required.' });
  }
  next();
}

function requireStudent(req, res, next) {
  const token = (req.headers.authorization || '').replace('Bearer ', '');
  if (!token || !studentSessions.has(token)) {
    return res.status(401).json({ error: 'Student login required.' });
  }
  req.studentId = studentSessions.get(token);
  next();
}

const app = express();
app.use(cors());
app.use(express.json());

/* =========================================================
   FILE-BACKED "DATABASE"
   Reads/writes a JSON file on disk. Fine for a single small
   institute on a local network. If this ever needs to support
   many concurrent users or grow large, swap readDb/writeDb for
   a real database (SQLite/Postgres) — every route below would
   stay the same, only these two functions would change.
   ========================================================= */
function readDb() {
  const raw = fs.readFileSync(DB_PATH, 'utf8');
  return JSON.parse(raw);
}
function writeDb(db) {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}

function isValidEmail(email) {
  return typeof email === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function last7Days() {
  const days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    days.push(d.toISOString().slice(0, 10));
  }
  return days;
}

/* =========================================================
   GRADING
   Policy: a student needs at least ATTENDANCE_THRESHOLD% overall
   attendance to be eligible. If eligible, their grade is simply
   their final exam average (100% of the grade comes from exams).
   If not eligible, they fail regardless of exam scores.
   ========================================================= */
function attendancePercentFor(studentId, db) {
  const record = db.attendance[studentId];
  if (!record) return null;
  const marked = Object.values(record);
  if (marked.length === 0) return null;
  const present = marked.filter(s => s === 'present').length;
  return Math.round((present / marked.length) * 100);
}

function examAverageFor(studentId, db) {
  const list = db.grades.filter(g => g.studentId === studentId);
  if (list.length === 0) return null;
  return Math.round(list.reduce((a, g) => a + g.score, 0) / list.length);
}

function resultFor(studentId, db) {
  const attendancePct = attendancePercentFor(studentId, db);
  const examAvg = examAverageFor(studentId, db);

  if (attendancePct === null) {
    return { attendancePct, examAvg, status: 'No attendance recorded yet', eligible: null };
  }
  if (attendancePct < ATTENDANCE_THRESHOLD) {
    return { attendancePct, examAvg, status: `Not eligible — attendance below ${ATTENDANCE_THRESHOLD}%`, eligible: false };
  }
  if (examAvg === null) {
    return { attendancePct, examAvg, status: 'Eligible — awaiting exam scores', eligible: true };
  }
  return {
    attendancePct,
    examAvg,
    status: examAvg >= PASS_MARK ? 'Pass' : 'Fail',
    eligible: true,
  };
}

/* =========================================================
   AUTH
   ========================================================= */
app.post('/api/auth/admin/login', (req, res) => {
  const { password } = req.body;
  if (password !== ADMIN_PASSWORD) {
    return res.status(401).json({ error: 'Incorrect password.' });
  }
  const token = newToken();
  adminSessions.add(token);
  res.json({ token });
});

app.post('/api/auth/admin/logout', requireAdmin, (req, res) => {
  const token = (req.headers.authorization || '').replace('Bearer ', '');
  adminSessions.delete(token);
  res.json({ ok: true });
});

app.post('/api/auth/student/login', (req, res) => {
  const db = readDb();
  const { email, birthdate } = req.body;
  const student = db.students.find(
    s => s.email.toLowerCase() === (email || '').trim().toLowerCase()
  );
  if (!student || !student.birthdate || student.birthdate !== birthdate) {
    return res.status(401).json({ error: 'No matching student found. Check your email and birthdate.' });
  }
  const token = newToken();
  studentSessions.set(token, student.id);
  res.json({ token, studentId: student.id });
});

app.get('/api/me', requireStudent, (req, res) => {
  const db = readDb();
  const student = db.students.find(s => s.id === req.studentId);
  if (!student) return res.status(404).json({ error: 'Student record not found.' });
  const result = resultFor(student.id, db);
  const grades = db.grades.filter(g => g.studentId === student.id);
  res.json({ student, result, grades, attendanceThreshold: ATTENDANCE_THRESHOLD, passMark: PASS_MARK });
});

/* =========================================================
   STUDENTS
   ========================================================= */
app.get('/api/students', requireAdmin, (req, res) => {
  const db = readDb();
  res.json(db.students);
});

app.post('/api/students', requireAdmin, (req, res) => {
  const db = readDb();
  const { name, email, phone, birthdate, grade } = req.body;

  if (!name || !name.trim()) return res.status(400).json({ error: 'Name is required.' });
  if (!isValidEmail(email)) return res.status(400).json({ error: 'A valid email is required.' });
  if (db.students.some(s => s.email.toLowerCase() === email.toLowerCase())) {
    return res.status(409).json({ error: 'A student with this email already exists.' });
  }

  const student = {
    id: db.nextStudentId++,
    name: name.trim(),
    email: email.trim(),
    phone: (phone || '').trim(),
    birthdate: birthdate || '',
    grade: grade || 'Waiting List',
    completed: false,
  };
  db.students.push(student);
  writeDb(db);
  res.status(201).json(student);
});

app.put('/api/students/:id', requireAdmin, (req, res) => {
  const db = readDb();
  const id = parseInt(req.params.id, 10);
  const student = db.students.find(s => s.id === id);
  if (!student) return res.status(404).json({ error: 'Student not found.' });

  const { name, email, phone, birthdate, grade, completed } = req.body;

  if (email !== undefined) {
    if (!isValidEmail(email)) return res.status(400).json({ error: 'A valid email is required.' });
    if (db.students.some(s => s.email.toLowerCase() === email.toLowerCase() && s.id !== id)) {
      return res.status(409).json({ error: 'Another student already uses this email.' });
    }
  }
  if (name !== undefined && !name.trim()) {
    return res.status(400).json({ error: 'Name is required.' });
  }

  if (name !== undefined) student.name = name.trim();
  if (email !== undefined) student.email = email.trim();
  if (phone !== undefined) student.phone = phone.trim();
  if (birthdate !== undefined) student.birthdate = birthdate;
  if (grade !== undefined) student.grade = grade;
  if (completed !== undefined) student.completed = !!completed;

  writeDb(db);
  res.json(student);
});

app.delete('/api/students/:id', requireAdmin, (req, res) => {
  const db = readDb();
  const id = parseInt(req.params.id, 10);
  const before = db.students.length;
  db.students = db.students.filter(s => s.id !== id);
  db.grades = db.grades.filter(g => g.studentId !== id);
  delete db.attendance[id];
  writeDb(db);
  res.json({ deleted: before !== db.students.length });
});

app.post('/api/students/bulk', requireAdmin, (req, res) => {
  const db = readDb();
  const rows = Array.isArray(req.body.rows) ? req.body.rows : [];
  let added = 0, skipped = 0;

  rows.forEach(r => {
    if (!r.name || !isValidEmail(r.email)) { skipped++; return; }
    if (db.students.some(s => s.email.toLowerCase() === r.email.toLowerCase())) { skipped++; return; }
    db.students.push({
      id: db.nextStudentId++,
      name: r.name,
      email: r.email,
      phone: r.phone || '',
      birthdate: r.birthdate || '',
      grade: r.grade || 'Waiting List',
      completed: false,
    });
    added++;
  });

  writeDb(db);
  res.json({ added, skipped });
});

/* =========================================================
   STAFF
   ========================================================= */
app.get('/api/staff', requireAdmin, (req, res) => {
  const db = readDb();
  res.json(db.staff);
});

app.post('/api/staff', requireAdmin, (req, res) => {
  const db = readDb();
  const { name, email, role, assignedClass, phone } = req.body;

  if (!name || !name.trim()) return res.status(400).json({ error: 'Name is required.' });
  if (!isValidEmail(email)) return res.status(400).json({ error: 'A valid email is required.' });
  if (db.staff.some(s => s.email.toLowerCase() === email.toLowerCase())) {
    return res.status(409).json({ error: 'A staff member with this email already exists.' });
  }

  const member = {
    id: db.nextStaffId++,
    name: name.trim(),
    email: email.trim(),
    role: role || 'Teacher',
    assignedClass: assignedClass || '',
    phone: (phone || '').trim(),
  };
  db.staff.push(member);
  writeDb(db);
  res.status(201).json(member);
});

app.put('/api/staff/:id', requireAdmin, (req, res) => {
  const db = readDb();
  const id = parseInt(req.params.id, 10);
  const member = db.staff.find(s => s.id === id);
  if (!member) return res.status(404).json({ error: 'Staff member not found.' });

  const { name, email, role, assignedClass, phone } = req.body;

  if (email !== undefined) {
    if (!isValidEmail(email)) return res.status(400).json({ error: 'A valid email is required.' });
    if (db.staff.some(s => s.email.toLowerCase() === email.toLowerCase() && s.id !== id)) {
      return res.status(409).json({ error: 'Another staff member already uses this email.' });
    }
  }
  if (name !== undefined && !name.trim()) {
    return res.status(400).json({ error: 'Name is required.' });
  }

  if (name !== undefined) member.name = name.trim();
  if (email !== undefined) member.email = email.trim();
  if (role !== undefined) member.role = role;
  if (assignedClass !== undefined) member.assignedClass = assignedClass;
  if (phone !== undefined) member.phone = phone.trim();

  writeDb(db);
  res.json(member);
});

app.delete('/api/staff/:id', requireAdmin, (req, res) => {
  const db = readDb();
  const id = parseInt(req.params.id, 10);
  const before = db.staff.length;
  db.staff = db.staff.filter(s => s.id !== id);
  writeDb(db);
  res.json({ deleted: before !== db.staff.length });
});

app.post('/api/staff/bulk', requireAdmin, (req, res) => {
  const db = readDb();
  const rows = Array.isArray(req.body.rows) ? req.body.rows : [];
  let added = 0, skipped = 0;

  rows.forEach(r => {
    if (!r.name || !isValidEmail(r.email)) { skipped++; return; }
    if (db.staff.some(s => s.email.toLowerCase() === r.email.toLowerCase())) { skipped++; return; }
    db.staff.push({
      id: db.nextStaffId++,
      name: r.name,
      email: r.email,
      role: r.role || 'Teacher',
      assignedClass: r.assignedClass || '',
      phone: r.phone || '',
    });
    added++;
  });

  writeDb(db);
  res.json({ added, skipped });
});

app.get('/api/results', requireAdmin, (req, res) => {
  const db = readDb();
  const results = db.students.map(s => ({ studentId: s.id, ...resultFor(s.id, db) }));
  res.json({ results, attendanceThreshold: ATTENDANCE_THRESHOLD, passMark: PASS_MARK });
});

/* =========================================================
   GRADES
   ========================================================= */
app.get('/api/grades', requireAdmin, (req, res) => {
  const db = readDb();
  res.json(db.grades);
});

app.put('/api/grades', requireAdmin, (req, res) => {
  const db = readDb();
  const { studentId, subject, score } = req.body;
  if (studentId === undefined || !subject) {
    return res.status(400).json({ error: 'studentId and subject are required.' });
  }
  const clamped = Math.max(0, Math.min(100, Math.round(Number(score))));
  let g = db.grades.find(g => g.studentId === studentId && g.subject === subject);
  if (g) g.score = clamped;
  else db.grades.push({ studentId, subject, score: clamped });
  writeDb(db);
  res.json({ studentId, subject, score: clamped });
});

/* =========================================================
   ATTENDANCE
   ========================================================= */
app.get('/api/attendance', requireAdmin, (req, res) => {
  const db = readDb();
  res.json({ attendance: db.attendance, days: last7Days() });
});

app.put('/api/attendance/cycle', requireAdmin, (req, res) => {
  const db = readDb();
  const { studentId, date } = req.body;
  if (studentId === undefined || !date) {
    return res.status(400).json({ error: 'studentId and date are required.' });
  }
  if (!db.attendance[studentId]) db.attendance[studentId] = {};
  const cur = db.attendance[studentId][date] || 'unmarked';
  const next = cur === 'unmarked' ? 'present' : cur === 'present' ? 'absent' : 'unmarked';
  if (next === 'unmarked') delete db.attendance[studentId][date];
  else db.attendance[studentId][date] = next;
  writeDb(db);
  res.json({ studentId, date, status: next });
});

/* =========================================================
   STATIC FRONTEND
   Serves the dashboard itself, so the browser and API share
   one origin (no CORS headaches, one URL to remember).
   ========================================================= */
app.use(express.static(path.join(__dirname, 'public')));

app.listen(PORT, () => {
  console.log(`King Sejong Institute dashboard running at http://localhost:${PORT}`);
});
